=========================================================================================
Threats and Countermeasures: Security Settings in Windows Server 2003 and Windows XP V2.0

                               (c) Microsoft 2003 - 2005

Released December 27, 2005
=========================================================================================

Threats and Countermeasures: Security Settings in Windows Server 2003 and Windows XP Download

TechNet:  http://go.microsoft.com/fwlink/?LinkId=15159
Download: http://go.microsoft.com/fwlink/?LinkId=15160

Threats and Countermeasures: Security Settings in Windows Server 2003 and Windows XP contains detailed information about relevant security settings that can be configured on Microsoft Windows Server 2003 and Windows XP. This guide details the different threats, potential countermeasures, and the potential impact of configuring these settings.

=========================================================================================

Folder contents of the Threats_and_Countermeasures_Guide.zip file:

<Threats and Countermeasures Guide>

	Threats and Countermeasures Guide.doc
		Chapter 1: Introduction to Threats and Countermeasures: Security Settings in Windows Server 2003 and Windows XP
		This chapter includes an overview of the guide, descriptions of the intended audience, the problems that are discussed in the guide, and the overall intent of the guide.

		Chapter 2: Domain Level Policies
		This chapter discusses the Group Policy settings that are applied at the domain level: password policies, account lockout policies, and Kerberos authentication protocol policies.

		Chapter 3: Audit Policy
		This chapter discusses the use of Audit policies to monitor and enforce your security measures.

		Chapter 4: User Rights
		This chapter discusses the various logon rights and privileges that are provided by the Windows operating systems, and provides guidance about which accounts should be assigned these rights.

		Chapter 5: Security Options
		This chapter introduces the "Security Options" section of Group Policy and provides guidance about security settings for digital data signatures, Administrator and Guest account names, access to floppy disk and CD-ROM drives, driver installation behavior, and logon prompts.

		Chapter 6: Event Log
		This chapter provides guidance about how to configure the settings that relate to the various event logs on Windows Server 2003 and Windows XP computers.

		Chapter 7: System Services
		This chapter lists the various system services that come with the operating systems and provides specific recommendations about which ones to leave enabled and which ones can be safely disabled.

		Chapter 8: Software Restriction Policies
		This chapter provides a brief overview of the software restriction policy mechanism, which was introduced in Windows XP and Windows Server 2003.

		Chapter 9: Windows XP and Windows Server 2003 Administrative Templates
		This chapter lists the security-related settings that are available through the Group Policy Administrative Templates.

		Chapter 10: Additional Registry Entries
		This chapter provides information about additional registry entries that are not listed in the Administrative Template file, but are present in the baseline security template.

		Chapter 11: Additional Countermeasures
		This chapter describes a number of additional security measures that may need to be applied to your computers but that cannot be easily applied through Group Policy or other automated means.

		Chapter 12: Conclusion
		The final chapter reviews the important points of the guide in a brief overview of everything that was discussed in the previous chapters.

	ReleaseNotes.txt
		Threats and Countermeasures: Security Settings in Windows Server 2003 and Windows XP Release Notes

	Readme.txt
		This file (the file that you are reading)

	Threats and Countermeasures Guide Tools and Templates.msi
		When this file is executed, the following folder structure will 
		be created and populated with the following files:


<Threats and Countermeasures Guide Tools and Templates>

	Windows Default Security and Services Configuration.xls

<Threats and Countermeasures Guide Tools and Templates\SCE Update>

	Restore_SCE_to_Default.vbs
	Rollback_SCE_for_MSS_Regkeys.vbs
	sceregvl_W2K3_SP1_inf.txt	
	sceregvl_XPSP2_inf.txt
	Strings-sceregvl.txt
	Update_SCE_with_MSS_Regkeys.vbs
	Values-sceregvl.txt



=================================================================================
TERMS OF USE

We at Microsoft Corporation hope that the information in this download is valuable to you.

This download and all files contained within are subject to Microsoft's standard TERMS OF USE for microsoft.com.

The TERMS OF USE for this download are located at http://www.microsoft.com/info/cpyright.htm
