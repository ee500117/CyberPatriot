=================================================================================
The Services and Service Accounts Security Planning Guide

                               (c) Microsoft 2005

Version 1.0, released: May 31, 2005
=================================================================================

The Services and Service Accounts Security Planning Guide Download 

*** TechNet:  http://go.microsoft.com/fwlink/?LinkId=41311
*** Download: http://go.microsoft.com/fwlink/?LinkId=41312

Summary
-------
This guide is an important resource to plan strategies to run services securely under 
the Microsoft� Windows Server� 2003 and Windows� XP operating systems. It addresses 
the common problem of Windows services that are set to run with the highest possible 
privileges, which an attacker could compromise to gain full and unrestricted access 
to the computer or domain, or even to the entire forest. 

=================================================================================

Folder contents of The_Services_and_Service_Accounts_Security_Planning_Guide.zip:

	<The Services and Service Accounts Security Planning Guide>

		The Services and Service Accounts Security Planning Guide.pdf
			Chapter 1: Introduction
			Chapter 2: The Approach to Running Services More Securely
			Chapter 3: How To Run Services More Securely
			Chapter 4: Summary
			Acknowledgements: Guide acknowledgements page

		Readme.txt
			This Readme file

		ReleaseNotes.txt
			Release Notes


=================================================================================
TERMS OF USE

Microsoft Corporation hopes that the information in this download is valuable 
to you. This download and all files contained within are subject to the standard 
TERMS OF USE for microsoft.com. The TERMS OF USE for this download are located 
at http://www.microsoft.com/info/cpyright.htm
